# College Demonstration Checklist

- [ ] Start MySQL and Tomcat.
- [ ] Open the application login page.
- [ ] Register a new test account.
- [ ] Show duplicate-email rejection.
- [ ] Show password policy rejection.
- [ ] Log in successfully.
- [ ] Show protected dashboard.
- [ ] Show BCrypt hash in MySQL (do not reveal real passwords).
- [ ] Log out and try dashboard URL directly.
- [ ] Demonstrate failed-login lockout using a disposable test account.
- [ ] Show login_activity records.
- [ ] Explain prepared statements, CSRF token and session ID renewal.

## Suggested viva questions
1. What is authentication?
2. What is the difference between authentication and authorization?
3. Why should passwords not be stored in plain text?
4. What is BCrypt?
5. What is a salt in password hashing?
6. What is SQL injection?
7. How does PreparedStatement help prevent SQL injection?
8. What is session fixation?
9. Why is the session ID renewed after login?
10. What is CSRF?
11. What is a CSRF token?
12. Why is server-side validation required?
13. What is an authentication filter?
14. What is the purpose of a session timeout?
15. Why should HTTPS be used?
