# PROJECT REPORT

## Design and Development of a Secure Web-Based Authentication System Using Java

**Project-Based Learning (PBL) Report**

Student Name: __________________________

Roll / Enrollment Number: __________________________

Department: __________________________

College: __________________________

Academic Year: __________________________

Guide / Faculty: __________________________

---

## Abstract

The Secure Login and Registration System is a Java-based web application designed to demonstrate essential application security practices. It provides user registration, authentication, protected dashboard access and secure logout. Passwords are not stored in plain text; instead, the application uses BCrypt hashing. Database operations use JDBC prepared statements to reduce SQL injection risk. The application also validates user input, renews the session identifier after authentication, applies an inactivity timeout, checks CSRF tokens on form submissions and temporarily locks an account after repeated failed login attempts. MySQL stores user records and login activity. The project demonstrates how basic secure-coding practices can be combined to protect a small web application.

## 1. Introduction

Authentication is the process of verifying the identity of a user before granting access to an application. Weak authentication can expose personal information and allow unauthorized access. Common problems include plain-text password storage, SQL injection, weak input validation, session fixation and unlimited password guessing.

This project implements a simple authentication workflow using Java Servlets, JSP, JDBC and MySQL. It is intended for educational use and demonstrates practical security controls in a controlled local environment.

## 2. Problem Statement

Many basic web applications store credentials insecurely or do not properly validate login requests. They may also fail to restrict access to private pages. The objective is to develop a small web application that demonstrates safer credential storage, secure database access, session handling and basic protection against repeated login failures.

## 3. Objectives

1. Build a user-friendly registration and login interface.
2. Store passwords as BCrypt hashes rather than plain text.
3. Use prepared statements for all user-controlled database values.
4. Validate user inputs on the server.
5. Restrict dashboard access to authenticated users.
6. renew the session ID after successful authentication.
7. Expire inactive sessions after 15 minutes.
8. Validate CSRF tokens on state-changing form submissions.
9. Temporarily lock an account after repeated failed login attempts.
10. Record login activity for demonstration and review.

## 4. Scope

The application supports local user registration, login, logout and access to a protected dashboard. It stores user details and login activity in MySQL. It does not include production-grade password reset, multi-factor authentication, email verification, administrator management or distributed rate limiting.

## 5. Tools and Technologies

- Java 17: application programming language.
- Jakarta Servlet 6 and JSP: server-side web application components.
- Apache Tomcat 10.1: servlet container.
- MySQL 8: relational database.
- JDBC: database connectivity.
- BCrypt (jBCrypt): password hashing.
- HTML and CSS: user interface.
- Maven: dependency and build management.

## 6. System Modules

### 6.1 Registration Module
Collects the user's name, email and password. It checks input validity, verifies that the email is not already registered and stores a BCrypt hash.

### 6.2 Login Module
Accepts email and password, checks whether the account is temporarily locked, verifies the submitted password against the stored BCrypt hash and creates an authenticated session on success.

### 6.3 Password Security Module
Uses BCrypt with a work factor of 12. BCrypt generates a salt and stores it as part of the encoded hash. The original password is not stored.

### 6.4 Session Management Module
Renews the session ID after login, stores the authenticated user in the session and sets a 15-minute inactivity timeout. The authentication filter protects the dashboard.

### 6.5 Login Protection Module
Tracks failed attempts. After five failed attempts for a known account, login is temporarily blocked for 15 minutes. This is a classroom demonstration control and should be strengthened for production use.

### 6.6 CSRF Protection Module
Creates a random token in the user's session and requires the token in POST forms. Requests with missing or incorrect tokens are rejected.

### 6.7 Audit Module
Stores login success/failure, attempted email, IP address and timestamp in the `login_activity` table.

## 7. System Architecture

Browser (HTML/CSS/JSP)
→ Java Servlets
→ Validation and authentication logic
→ JDBC / PreparedStatement
→ MySQL database

The authentication filter checks access to the dashboard before the request reaches the dashboard servlet.

## 8. Database Design

### users table
- id: unique user identifier (primary key)
- full_name: user's name
- email: unique email address
- password_hash: BCrypt password hash
- failed_attempts: failed login counter
- locked_until: temporary lock expiry time
- created_at: account creation timestamp

### login_activity table
- id: unique activity identifier
- user_id: related user, nullable
- email_attempted: email submitted during login
- success: whether authentication succeeded
- ip_address: request IP address
- attempted_at: event timestamp

Relationship: one user may have many login activity records. The foreign key uses `ON DELETE SET NULL` to preserve the audit record if an account is removed.

## 9. Security Features and Their Purpose

| Security control | Purpose |
|---|---|
| BCrypt hashing | Makes offline password guessing harder if the database is exposed |
| PreparedStatement | Separates SQL code from user-supplied values |
| Server-side validation | Rejects malformed or out-of-policy input |
| Session ID renewal | Reduces session fixation risk |
| Authentication filter | Prevents unauthenticated dashboard access |
| Session timeout | Limits exposure from unattended sessions |
| CSRF token | Helps prevent cross-site request forgery |
| Failed-login lock | Slows repeated password guessing |
| Audit log | Provides a record of authentication attempts |

## 10. Implementation Procedure

1. Install JDK 17, Maven, MySQL and Tomcat 10.1.
2. Create the MySQL database using `database/schema.sql`.
3. Configure database connection details in `db.properties`.
4. Import the Maven project into Eclipse or IntelliJ.
5. Build the WAR using `mvn clean package`.
6. Deploy the WAR to Tomcat.
7. Open the application in a browser.
8. Register a user and test the login process.
9. Test access control, invalid credentials, CSRF validation and account lock behavior.

## 11. Testing Plan

| Test case | Input / action | Expected result |
|---|---|---|
| Valid registration | Valid name, unique email, strong password | Account created |
| Duplicate registration | Existing email | Registration rejected |
| Weak password | Password missing required character class | Registration rejected |
| Correct login | Correct email and password | Dashboard opens |
| Wrong password | Incorrect password | Generic login error |
| Repeated failures | Five failed attempts on known account | Temporary lock |
| Direct dashboard access | Open dashboard without login | Redirect to login |
| Logout | Submit logout form | Session invalidated |
| Invalid CSRF token | Submit POST with incorrect token | HTTP 403 |
| SQL injection string | Enter SQL-like text in email field | Treated as data / rejected by validation |

## 12. Demonstration Procedure

1. Open the application login page.
2. Select Create an account.
3. Register with a valid name, email and strong password.
4. Sign in with the registered credentials.
5. Show the protected dashboard.
6. Open MySQL Workbench and show that `password_hash` contains a BCrypt hash, not the original password.
7. Sign out and attempt to access the dashboard directly.
8. Demonstrate invalid login attempts and temporary lock behavior.
9. Show the `login_activity` table.

Use a test account and a local database for demonstrations. Do not use real passwords.

## 13. Limitations

- The project is designed for local academic demonstration.
- The basic lockout approach can be abused to deny access to another user's account.
- HTTPS and secure cookie configuration must be enabled before deployment beyond localhost.
- Email verification, password reset, MFA and administrator controls are not included.
- A production deployment needs stronger rate limiting, monitoring, secret management and security review.

## 14. Future Enhancements

1. Add email OTP or authenticator-based MFA.
2. Add secure password reset.
3. Add administrator dashboard and user management.
4. Add CAPTCHA or risk-based rate limiting.
5. Add account verification through email.
6. Add security headers and HTTPS-only deployment.
7. Add automated unit and integration tests.

## 15. Conclusion

The project demonstrates how a Java web application can implement core authentication security controls. BCrypt password hashing, prepared statements, input validation, CSRF protection, session management and login-attempt controls improve the security of the registration and login workflow. The project provides a practical foundation for understanding secure application development and can be extended with additional security features.

## References

1. OWASP Foundation, Password Storage Cheat Sheet.
2. OWASP Foundation, SQL Injection Prevention Cheat Sheet.
3. OWASP Foundation, Cross-Site Request Forgery Prevention Cheat Sheet.
4. OWASP Foundation, Session Management Cheat Sheet.
5. Oracle, Java Platform Documentation.
6. Jakarta Servlet Specification.
7. MySQL Reference Manual.
