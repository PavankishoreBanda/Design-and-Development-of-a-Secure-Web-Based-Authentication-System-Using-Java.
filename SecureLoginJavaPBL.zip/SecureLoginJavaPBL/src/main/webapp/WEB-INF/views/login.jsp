<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="edu.college.security.Csrf" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Secure Login</title><link rel="stylesheet" href="<%=request.getContextPath()%>/assets/style.css"></head>
<body><main class="card"><div class="brand">🔐 SecureGate</div><h1>Welcome back</h1><p class="muted">Sign in to your protected account.</p>
<% if ("1".equals(request.getParameter("registered"))) { %><div class="success">Registration successful. Please sign in.</div><% } %>
<% if ("1".equals(request.getParameter("logout"))) { %><div class="success">You have been logged out.</div><% } %>
<% if (request.getAttribute("error") != null) { %><div class="error"><%=request.getAttribute("error")%></div><% } %>
<form method="post" action="<%=request.getContextPath()%>/login">
<input type="hidden" name="csrfToken" value="<%=Csrf.token(session)%>">
<label>Email address</label><input type="email" name="email" required maxlength="190" autocomplete="username">
<label>Password</label><input type="password" name="password" required autocomplete="current-password">
<button type="submit">Sign in</button></form><p class="foot">New here? <a href="<%=request.getContextPath()%>/register">Create an account</a></p>
</main></body></html>
