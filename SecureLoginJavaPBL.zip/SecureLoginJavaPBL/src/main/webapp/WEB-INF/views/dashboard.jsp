<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="edu.college.security.User,edu.college.security.Csrf,edu.college.security.Html" %>
<% User user = (User) session.getAttribute("user"); %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard</title><link rel="stylesheet" href="<%=request.getContextPath()%>/assets/style.css"></head>
<body><main class="card wide"><div class="brand">🔐 SecureGate</div><div class="pill">Authenticated session</div>
<h1>Hello, <%=Html.escape(user.getFullName())%>!</h1><p class="muted">You have successfully accessed the protected dashboard.</p>
<section class="panel"><h2>Account details</h2><p><strong>Name:</strong> <%=Html.escape(user.getFullName())%></p><p><strong>Email:</strong> <%=Html.escape(user.getEmail())%></p></section>
<section class="panel"><h2>Security features active</h2><ul><li>BCrypt password hashing</li><li>Prepared statements for database queries</li><li>Session-based access control</li><li>15-minute idle session timeout</li><li>CSRF token validation on forms</li><li>Temporary lock after repeated failed attempts</li></ul></section>
<form method="post" action="<%=request.getContextPath()%>/logout"><input type="hidden" name="csrfToken" value="<%=Csrf.token(session)%>"><button class="secondary" type="submit">Log out securely</button></form>
</main></body></html>
