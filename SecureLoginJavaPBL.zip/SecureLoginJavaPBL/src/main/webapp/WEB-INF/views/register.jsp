<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="edu.college.security.Csrf" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Create Account</title><link rel="stylesheet" href="<%=request.getContextPath()%>/assets/style.css"></head>
<body><main class="card"><div class="brand">🔐 SecureGate</div><h1>Create account</h1><p class="muted">Register for secure access.</p>
<% if (request.getAttribute("error") != null) { %><div class="error"><%=request.getAttribute("error")%></div><% } %>
<form method="post" action="<%=request.getContextPath()%>/register">
<input type="hidden" name="csrfToken" value="<%=Csrf.token(session)%>">
<label>Full name</label><input type="text" name="fullName" required minlength="2" maxlength="100" autocomplete="name">
<label>Email address</label><input type="email" name="email" required maxlength="190" autocomplete="email">
<label>Password</label><input type="password" name="password" required minlength="8" maxlength="72" autocomplete="new-password">
<small>Use 8–72 characters, including uppercase, lowercase, a number and a symbol.</small>
<label>Confirm password</label><input type="password" name="confirmPassword" required autocomplete="new-password">
<button type="submit">Create account</button></form><p class="foot">Already registered? <a href="<%=request.getContextPath()%>/login">Sign in</a></p>
</main></body></html>
