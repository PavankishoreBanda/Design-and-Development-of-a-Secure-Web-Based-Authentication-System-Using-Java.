package edu.college.security;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.mindrot.jbcrypt.BCrypt;
import java.io.IOException;
import java.util.Locale;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private final UserDAO dao = new UserDAO();

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, resp);
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Csrf.valid(req)) { resp.sendError(403, "Invalid form token. Refresh and try again."); return; }
        String name = req.getParameter("fullName");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String confirm = req.getParameter("confirmPassword");
        name = name == null ? "" : name.trim();
        email = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);

        try {
            if (!Validation.validName(name) || !Validation.validEmail(email) || !Validation.validPassword(password)) {
                req.setAttribute("error", "Check your details. Password must be 8–72 characters with upper/lowercase, a number and a symbol.");
                req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, resp); return;
            }
            if (!password.equals(confirm)) {
                req.setAttribute("error", "Passwords do not match.");
                req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, resp); return;
            }
            if (dao.emailExists(email)) {
                req.setAttribute("error", "An account with that email already exists.");
                req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, resp); return;
            }
            dao.createUser(name, email, BCrypt.hashpw(password, BCrypt.gensalt(12)));
            resp.sendRedirect(req.getContextPath() + "/login?registered=1");
        } catch (Exception e) {
            throw new ServletException("Unable to complete registration.", e);
        }
    }
}
