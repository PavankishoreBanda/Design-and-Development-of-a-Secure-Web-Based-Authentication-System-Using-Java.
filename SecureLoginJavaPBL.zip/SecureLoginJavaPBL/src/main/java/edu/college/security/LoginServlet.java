package edu.college.security;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.mindrot.jbcrypt.BCrypt;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Locale;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private final UserDAO dao = new UserDAO();

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Csrf.valid(req)) { resp.sendError(403, "Invalid form token. Refresh and try again."); return; }
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        email = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
        String ip = req.getRemoteAddr();

        try {
            if (!Validation.validEmail(email) || password == null || password.isEmpty()) {
                req.setAttribute("error", "Invalid email or password.");
                req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp); return;
            }

            Timestamp lockedUntil = dao.getLockedUntil(email);
            if (lockedUntil != null && lockedUntil.after(new Timestamp(System.currentTimeMillis()))) {
                dao.logActivity(null, email, false, ip);
                req.setAttribute("error", "Account temporarily locked. Please try again after 15 minutes.");
                req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp); return;
            }

            String hash = dao.findPasswordHash(email);
            if (hash != null && BCrypt.checkpw(password, hash)) {
                User user = dao.findByEmail(email);
                dao.resetFailedAttempts(email);
                dao.logActivity(user.getId(), email, true, ip);

                HttpSession old = req.getSession(false);
                if (old != null) old.invalidate();
                HttpSession session = req.getSession(true);
                req.changeSessionId();
                session.setAttribute("user", user);
                Csrf.token(session);
                session.setMaxInactiveInterval(15 * 60);
                resp.sendRedirect(req.getContextPath() + "/dashboard");
            } else {
                dao.recordFailedAttempt(email);
                dao.logActivity(null, email, false, ip);
                req.setAttribute("error", "Invalid email or password.");
                req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            throw new ServletException("Unable to process login.", e);
        }
    }
}
