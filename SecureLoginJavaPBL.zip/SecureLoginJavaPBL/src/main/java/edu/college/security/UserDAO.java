package edu.college.security;

import java.sql.*;
import java.time.LocalDateTime;

public class UserDAO {
    public boolean emailExists(String email) throws Exception {
        String sql = "SELECT id FROM users WHERE email = ?";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    public void createUser(String fullName, String email, String passwordHash) throws Exception {
        String sql = "INSERT INTO users(full_name, email, password_hash) VALUES (?, ?, ?)";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, fullName);
            ps.setString(2, email);
            ps.setString(3, passwordHash);
            ps.executeUpdate();
        }
    }

    public User findByEmail(String email) throws Exception {
        String sql = "SELECT id, full_name, email FROM users WHERE email = ?";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? new User(rs.getLong("id"), rs.getString("full_name"), rs.getString("email")) : null;
            }
        }
    }

    public String findPasswordHash(String email) throws Exception {
        String sql = "SELECT password_hash FROM users WHERE email = ?";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getString(1) : null; }
        }
    }

    public Timestamp getLockedUntil(String email) throws Exception {
        String sql = "SELECT locked_until FROM users WHERE email = ?";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getTimestamp(1);
                return null;
            }
        }
    }

    public void recordFailedAttempt(String email) throws Exception {
        String sql = "UPDATE users SET failed_attempts = failed_attempts + 1, " +
                     "locked_until = CASE WHEN failed_attempts + 1 >= 5 THEN DATE_ADD(NOW(), INTERVAL 15 MINUTE) ELSE locked_until END " +
                     "WHERE email = ?";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.executeUpdate();
        }
    }

    public void resetFailedAttempts(String email) throws Exception {
        String sql = "UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE email = ?";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.executeUpdate();
        }
    }

    public void logActivity(Long userId, String email, boolean success, String ip) throws Exception {
        String sql = "INSERT INTO login_activity(user_id, email_attempted, success, ip_address) VALUES (?, ?, ?, ?)";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (userId == null) ps.setNull(1, Types.BIGINT); else ps.setLong(1, userId);
            ps.setString(2, email);
            ps.setBoolean(3, success);
            ps.setString(4, ip);
            ps.executeUpdate();
        }
    }
}
