package edu.college.security;

import java.util.regex.Pattern;

public final class Validation {
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private Validation() {}

    public static boolean validName(String name) {
        return name != null && name.trim().length() >= 2 && name.trim().length() <= 100;
    }
    public static boolean validEmail(String email) {
        return email != null && email.length() <= 190 && EMAIL.matcher(email).matches();
    }
    public static boolean validPassword(String password) {
        return password != null && password.length() >= 8 && password.length() <= 72
            && password.matches(".*[A-Z].*")
            && password.matches(".*[a-z].*")
            && password.matches(".*[0-9].*")
            && password.matches(".*[^A-Za-z0-9].*");
    }
}
